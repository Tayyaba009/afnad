<?php 
include_once('connection.php');

if (isset($_POST['Videos_Id']) && isset($_POST['comment'])){


	$data = Array(
		  'Consumers_ID'	=>$_POST['userid'],
		  'Videos_Id'	=>$_POST['Videos_Id'],
		  'Description'	=>$_POST['comment'],
	  	'Create_Date' => date('Y-m-d')
		  );
		  

		$db->insert('creators_comments', $data);
	
}else{
    error_log("Invalid request or missing data.");
}

?>