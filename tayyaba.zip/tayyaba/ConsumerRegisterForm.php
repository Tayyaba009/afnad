<?php 
include_once('connection.php');

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$msg = "";

if(isset($_POST['Register'])){

    $db->where('Email', $_POST['Email']);
    $user = $db->get('consumers');
    if ($user != NULL) {
      
        echo "Email Already Exist.";
        exit (0);
    }
    
    $data = Array(
        'First_Name'=> $_POST['First_Name'],
        'Email'=> $_POST['Email'],
        'Last_Name'=> $_POST['Last_Name'],
        'Creation_Date' => date('Y-m-d'),
        'Address'=> $_POST['Address'],
        'Password'=> md5($_POST['Password'])
        );
        
    $user = $db->insert('consumers', $data);
  if($user){

 header('Location: SingIn.php');
    
  } else
  {
     echo "Some thing went Wrong.";
    exit (0);
  }
        
}
        



?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="zxx">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <title>ePathsala - Online Education Template</title>
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="images/cropped-epathsala_favicon-192x192.png" />
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!--Custom CSS-->
    <link href="css/style.css" rel="stylesheet" type="text/css" />
    <!--Plugin CSS-->
    <link href="css/plugin.css" rel="stylesheet" type="text/css" />
    <!--Font Awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css" />
  </head>
  <body>
    <!-- Preloader -->
    <div id="preloader">
      <div id="status"></div>
    </div>
    <!-- Preloader Ends -->

    <!-- header starts -->
      <?php include_once('Header.php');?>
    <!-- header ends -->

    <!-- Breadcrumb starts -->
    <section class="breadcrumb-main">
      <div class="container">
        <div class="breadcrumb-inner">
          <h2>Register</h2>
        </div>
      </div>
      <div class="sl-overlay"></div>
    </section>
    <!-- Breadcrumb end -->

    <!-- Contact start -->
    <section class="contact-main pb-0">
      <div class="container">

        <div class="contact-form">
          <form class="m-auto text-center" action="ConsumerRegisterForm.php" method="post">
            <!-- 2 column grid layout with text inputs for the first and last names -->
            <div class="row mb-4">
              <div class="col">
                <div class="form-outline">
                  <input type="text" id="First_Name" name = "First_Name" required class="form-control" placeholder="First Name" />
                </div>
              </div>
            </div>
                <div class="row mb-4">
              <div class="col">
                <div class="form-outline">
                  <input type="text" id="Last_Name" name = "Last_Name" required class="form-control" placeholder="Last Name" />
                </div>
              </div>
            </div>
            <!-- Email input -->
            <div class="form-outline mb-4">
              <input type="email" id="Email" name = "Email" required class="form-control" placeholder="Email" />
            </div>

            <!-- Number input -->
            <div class="form-outline mb-4">
              <input type="password" id="Password" required name = "Password" class="form-control" placeholder="Password" />
            </div>

            <!-- Message input -->
            <div class="form-outline mb-4">
              <textarea class="form-control" id="Address" name = "Address" placeholder="Address" rows="3"></textarea>
            </div>

            <!-- Submit button -->
            <button type="submit" class="btn" name = "Register">Send Message</button>
          </form>
        </div>
      </div>
    </section>
    <!-- Contact end -->
        <?php include_once('footer.php'); ?>
    <!-- Search form popup end -->

    <!-- Back to top start -->
    <div id="back-to-top">
      <a href="#"></a>
    </div>
    <!-- Back to top ends -->

    <!-- *Scripts* -->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugin.js"></script>
    <script src="js/main.js"></script>
    <script src="js/custom-swiper.js"></script>
    <script src="js/custom-nav.js"></script>
  </body>
</html>
