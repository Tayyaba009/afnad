<?php
 use phpformbuilder\database\Mysql;

require_once 'phpformbuilder/database/db-connect.php';
require_once 'phpformbuilder/database/Mysql.php';

$db = new Mysql();
if (! $db->Query("SELECT
  upload_videos.Title_of_Video,
  consumers.First_Name,
  consumers.Email,
  creators_comments.Description,
  creators_comments.Create_Date
FROM creators_comments
  INNER JOIN upload_videos
    ON creators_comments.Videos_Id = upload_videos.Videos_Id
  INNER JOIN consumers
    ON creators_comments.Consumers_ID = consumers.Consumers_ID")) $db->Kill();



?>
<!-- Main content -->
 <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table id="data" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>S No</th>
                                <th>Title</th>
                                <th>Email</th>
                                <th>Comment</th>
                                <th>Date</th>
                                
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php
							$i=0;
							$db->MoveFirst();
							while (! $db->EndOfSeek()) {
								$row = $db->Row();
    
								$i = $i+1;
                            ?>
                            
                            <tr>
                                <td><?=$i?></td>
                                <td><?=$row->Title_of_Video ?></td>
                                   <td><?=$row->Email ?></td>
                                   <td><?=$row->Description ?></td>
                                <td><?=$row->Create_Date?></td>
                           
                                
                               
                            </tr>
                            <?php }?>
                        </tbody>
                       
                    </table>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->

           
                
            <!-- /.box -->
        </div>
        <!-- /.col -->

<!-- /.content -->
  <script src="vendors/jquery/dist/jquery.min.js"></script>
<script>
    $(function () {
      
        $('#data').DataTable({
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
    });
</script>