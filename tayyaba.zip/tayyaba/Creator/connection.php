<?php 
    include_once 'apis/MysqliApi.php';
    $db = new MysqliDb ('localhost', 'root', '12345678910', 'assignments3');
    ?>