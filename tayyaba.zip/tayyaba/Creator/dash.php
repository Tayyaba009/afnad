<section class="content">
    <div class="row">
        <div class="col-lg-10 col-xs-10">
            <!-- small box -->            
        </div>
    </div>
</section>
