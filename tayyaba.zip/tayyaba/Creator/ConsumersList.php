<?php
 use phpformbuilder\database\Mysql;

require_once 'phpformbuilder/database/db-connect.php';
require_once 'phpformbuilder/database/Mysql.php';

$db = new Mysql();
if (! $db->Query("Select * from consumers")) $db->Kill();



?>
<!-- Main content -->
 <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table id="data" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>S No</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
								<th>Address</th>
                                <th>Account Creation Date</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php
							$i=0;
							$db->MoveFirst();
							while (! $db->EndOfSeek()) {
								$row = $db->Row();
    
								$i = $i+1;
                            ?>
                            
                            <tr>
                                <td><?=$i?></td>
                                <td><?=$row->First_Name ?></td>
                                   <td><?=$row->Last_Name ?></td>
								   <td><?=$row->Email ?></td>
								   <td><?=$row->Address ?></td>
                                <td><?=$row->Creation_Date?></td>
                                
                     
                                
                               
                            </tr>
                            <?php }?>
                        </tbody>
                       
                    </table>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->

           
                
            <!-- /.box -->
        </div>
        <!-- /.col -->

<!-- /.content -->
  <script src="vendors/jquery/dist/jquery.min.js"></script>
<script>
    $(function () {
      
        $('#data').DataTable({
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
    });
</script>