<?php

/* database connection */

if ($_SERVER['REMOTE_ADDR'] == '127.0.0.1') {
    define('DBUSER', 'root');
    define('DBPASS', '12345678910');
    define('DBHOST', 'localhost');
    define('DBNAME', 'assignments3');
} else {
    define('DBUSER', 'root');
    define('DBPASS', '12345678910');
    define('DBHOST', 'localhost');
    define('DBNAME', 'assignments3');
}
define('DB', 'mysql:host=' . DBHOST . ';dbname=' . DBNAME);

function GetUrl($keya, $vala, $url='')
{
 
if($url=='')
 	parse_str($_SERVER['QUERY_STRING'], $query);
else
	parse_str($url, $query);
	
 if ($vala=="")
 {
	 if (($key = array_search($keya, $query)) !== false) 
    	unset($query[$keya]);
}
else
 $query[$keya] = $vala;
 

 $newULR = http_build_query($query);
 
 return $newULR;
}

 



