<?php
namespace phpformbuilder;

use phpformbuilder\Validator\Validator;

class FormExtended extends Form
{

    /* =============================================
        Complete contact form
    ============================================= */

    public function createContactForm()
    {
        $this->startFieldset('Please fill in this form to contact us');
        $this->addHtml('<p class="text-warning">All fields are required</p>');
        $this->groupInputs('user-name', 'user-first-name');
        $this->setCols(0, 6, 'xs');
        $this->addIcon('user-name', '<span class="glyphicon glyphicon-user"></span>', 'before');
        $this->addInput('text', 'user-name', '', '', 'required=required, placeholder=Name');
        $this->addIcon('user-first-name', '<span class="glyphicon glyphicon-user"></span>', 'before');
        $this->addInput('text', 'user-first-name', '', '', 'required=required, placeholder=First Name');
        $this->setCols(0, 12, 'xs');
        $this->addIcon('user-email', '<span class="glyphicon glyphicon-envelope"></span>', 'before');
        $this->addInput('email', 'user-email', '', '', 'required=required, placeholder=Email');
        $this->addIcon('user-phone', '<span class="glyphicon glyphicon-earphone"></span>', 'before');
        $this->addInput('text', 'user-phone', '', '', 'required=required, placeholder=Phone');
        $this->addTextarea('message', '', '', 'cols=30, rows=4, required=required, placeholder=Message');
        $this->addPlugin('word-character-count', '#message', 'default', array('%maxAuthorized%' => 100));
        $this->addCheckbox('newsletter', 'Suscribe to Newsletter', 1, 'checked=checked');
        $this->printCheckboxGroup('newsletter', '');
        $this->setCols(3, 9, 'sm');
        $this->addInput('text', 'captcha', '', 'Type the following characters :', 'size=15');
        $this->addPlugin('captcha', '#captcha');
        $this->addBtn('submit', 'submit-btn', 1, 'Send <span class="glyphicon glyphicon-envelope append"></span>', 'class=btn btn-success');
        $this->endFieldset();
        if ($this->framework !== 'material') {
            $this->addPlugin('icheck', 'input', 'default', array('%theme%' => 'square-custom', '%color%' => 'green'));
        }
    }

    /* Contact form validation */

    public static function validateContactForm()
    {
        include_once __DIR__ . '/Validator/Validator.php';
        include_once __DIR__ . '/Validator/Exception.php';
        $validator = new Validator($_POST);
        $required = array('user-name', 'user-first-name', 'user-email', 'user-phone', 'message');
        foreach ($required as $required) {
            $validator->required()->validate($required);
        }
        $validator->maxLength(100)->validate('message');
        $validator->email()->validate('user-email');
        $validator->captcha('captcha')->validate('captcha');

        // check for errors

        if ($validator->hasErrors()) {
            $_SESSION['errors']['extended-contact-form'] = $validator->getAllErrors();

            return false;
        } else {
            return true;
        }
    }

    /* Standard form e-mail sending */

    public static function sendStandardEmail($address, $form_ID)
    {

        // get hostname
        $hostname = str_replace('www.', '', parse_url($_SERVER['REQUEST_URI'], PHP_URL_HOST));
        $from_email = 'contact@' . $hostname;
        $adress = $address;
        $subject = 'Message from ' . $hostname;
        $filter_values = $form_ID . ', captcha, submit-btn, captchaHash';
        $sent_message = self::sendMail($from_email, $adress, $subject, $filter_values);
        self::clear($form_ID);

        return $sent_message;
    }

    /* =============================================
        Fields shorcuts and groups for users
    ============================================= */

    public function addAddress($i = '')
    {
        $index = $this->getIndex($i);
        $index_text = $this->getIndexText($i);
        $this->setCols(3, 9);
        $this->addTextarea('address' . $index, '', 'Address' . $index_text, 'required=required');
        $this->groupInputs('zip_code' . $index, 'city' . $index);
        $this->setCols(3, 4);
        $this->addInput('text', 'zip_code' . $index, '', 'Zip Code' . $index_text, 'required=required');
        $this->setCols(2, 3);
        $this->addInput('text', 'city' . $index, '', 'City' . $index_text, 'required=required');
        $this->setCols(3, 9);
        $this->addCountrySelect('country' . $index, 'Country' . $index_text, 'required=required', ['flag_size' => 16, 'live_search' => true]);
    }

    public function addBirth($i = '')
    {
        $index = $this->getIndex($i);
        $index_text = $this->getIndexText($i);
        $this->setCols(3, 4);
        $this->groupInputs('birth_date' . $index, 'birth_zip_code' . $index);
        $this->addInput('text', 'birth_date' . $index, '', 'Birth Date' . $index_text, 'placeholder=click to open calendar');
        $this->addPlugin('pickadate-material', '#birth_date' . $index);
        $this->setCols(2, 3);
        $this->addInput('text', 'birth_zip_code' . $index, '', 'Birth Zip Code' . $index_text);
        $this->setCols(3, 4);
        $this->groupInputs('birth_city' . $index, 'birth_country' . $index);
        $this->addInput('text', 'birth_city' . $index, '', 'Birth  City' . $index_text);
        $this->setCols(2, 3);
        $this->addCountrySelect('birth_country' . $index, 'Birth Country' . $index_text, '', ['flag_size' => 16, 'live_search' => true]);
    }

    public function addCivilitySelect($i = '')
    {
        $index = $this->getIndex($i);
        $index_text = $this->getIndexText($i);
        $this->addOption('civility' . $index, 'M.', 'M.');
        $this->addOption('civility' . $index, 'M<sup>rs</sup>', 'Mrs');
        $this->addOption('civility' . $index, 'M<sup>s</sup>', 'Ms');
        $this->addSelect('civility' . $index, 'Civility' . $index_text, 'class=selectpicker, required=required');
    }

    public function addContact($i = '')
    {
        $index = $this->getIndex($i);
        $index_text = $this->getIndexText($i);
        $this->groupInputs('phone' . $index, 'mobile_phone' . $index);
        $this->setCols(3, 4);
        $this->addInput('text', 'phone' . $index, '', 'Phone' . $index_text);
        $this->setCols(2, 3);
        $this->addInput('text', 'mobile_phone' . $index, '', 'Mobile' . $index_text, 'required=required');
        $this->setCols(3, 9);
        $this->addInput('text', 'email_professional' . $index, '', 'BuisnessE-mail' . $index_text, 'required=required');
        $this->addInput('text', 'email_private' . $index, '', 'Personal E-mail' . $index_text);
    }

    public function addIdentity($i = '')
    {
        $index = $this->getIndex($i);
        $index_text = $this->getIndexText($i);
        $this->groupInputs('civility' . $index, 'name' . $index);
        $this->setCols(3, 2);
        $this->addCivilitySelect($i);
        $this->setCols(2, 5);
        $this->addInput('text', 'name' . $index, '', 'Name' . $index_text, 'required=required');
        $this->setCols(3, 9);
        $this->startDependantFields('civility' . $index, 'Mrs');
        $this->addInput('text', 'maiden_name' . $index, '', 'Maiden Name' . $index_text);
        $this->endDependantFields();
        $this->groupInputs('firstnames' . $index, 'citizenship' . $index);
        $this->setCols(3, 4);
        $this->addInput('text', 'firstnames' . $index, '', 'Firstnames' . $index_text, 'required=required');
        $this->setCols(2, 3);
        $this->addInput('text', 'citizenship' . $index, '', 'Citizenship' . $index_text);
    }

    /* Submit buttons */

    public function addBackSubmit()
    {
        $this->setCols(0, 12);
        $this->addHtml('<p>&nbsp;</p>');
        $this->addBtn('submit', 'back-btn', 1, 'Back', 'class=btn btn-warning', 'submit_group');
        $this->addBtn('submit', 'submit-btn', 1, 'Submit', 'class=btn btn-success', 'submit_group');
        $this->printBtnGroup('submit_group');
    }

    public function addCancelSubmit()
    {
        $this->setCols(3, 9);
        $this->addHtml('<p>&nbsp;</p>');
        $this->addBtn('button', 'cancel-btn', 1, 'Cancel', 'class=btn btn-default', 'submit_group');
        $this->addBtn('submit', 'submit-btn', 1, 'Submit', 'class=btn btn-success', 'submit_group');
        $this->printBtnGroup('submit_group');
    }

    private function getIndex($i)
    {
        if ($i !== '') {
            return '-' . $i;
        }

        return false;
    }
    private function getIndexText($i)
    {
        if ($i !== '') {
            return ' ' . $i;
        }

        return false;
    }
}
