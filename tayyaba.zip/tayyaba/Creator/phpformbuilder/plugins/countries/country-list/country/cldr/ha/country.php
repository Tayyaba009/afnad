<?php return array (
  'GH' => 'Gaana',
  'NE' => 'Nijer',
  'NG' => 'Nijeriya',
);
