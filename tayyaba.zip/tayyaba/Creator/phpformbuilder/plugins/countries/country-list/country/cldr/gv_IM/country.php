<?php return array (
  'IM' => 'Ellan Vannin',
  'GB' => 'Rywvaneth Unys',
);
