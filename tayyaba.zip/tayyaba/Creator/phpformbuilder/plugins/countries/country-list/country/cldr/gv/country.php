<?php return array (
  'GB' => 'Rywvaneth Unys',
);
