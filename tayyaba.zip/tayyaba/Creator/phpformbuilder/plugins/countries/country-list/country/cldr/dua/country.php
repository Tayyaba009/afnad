<?php return array (
  'CM' => 'Cameroun',
);
