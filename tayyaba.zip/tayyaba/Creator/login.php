<?php include_once 'connection.php';
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (isset($_POST['submit'])){

    $db->where("Creators_Name" , $_POST['Creators_Name']);
    $db->where("Password",  md5(trim($_POST['Password'])) );
    $user = $db->getOne("creators");


   /*
   echo $_POST['Creators_Name'] . '<br>';
    echo $_POST['Password'] . '<br>';
    echo $_POST['group'];
    print_r($user);
    */
   
  
    if ($user){

      $mCreators_Name = $user['Creators_Name'];
      $_SESSION['USERNAM'] = $mCreators_Name ;
      $_SESSION['USERID'] =$user['Creators_ID'] ;
        header("Location: index.php");

        
    } else
{
  echo  '<p class="alert alert-danger">Login Failed <br>Invalid Creators_Name or Password</p>' . " \n";
  }
    
}?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Login </title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="vendors/animate.css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <form action="login.php" method="post">
              <h1>Login Form</h1>

              <div>
                <input type="text" class="form-control" placeholder="User Name" required="" name = 'Creators_Name' />
              </div>
              <div>
                <input type="Password" name = 'Password' class="form-control" placeholder="Password" required="" />
              </div>
              <div>
                <button type="submit" name = 'submit' class="btn btn-primary btn-block btn-flat">Sign In</button>
                <a class="reset_pass" href="#">Lost your Password?</a>
              </div>

              <div class="clearfix"></div>

              <div class="separator">
               

                <div class="clearfix"></div>
                <br />

                <div>
                  <h1><i class="fa fa-paw"></i> Ulster!</h1>
                  <p>©2025 All Rights Reserved. Ulster</p>
                </div>
              </div>
            </form>
          </section>
        </div>

      </div>
    </div>
  </body>
</html>
