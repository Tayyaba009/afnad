$db = new MysqliDb(
    'dbs234.mysql.database.azure.com',  // Replace with your Azure MySQL hostname
    'root1@dbs234',                     // Replace with your Azure MySQL username
    'Allah512@',           // Replace with your Azure MySQL password
    'mydb'                              // Replace with your database name
);
